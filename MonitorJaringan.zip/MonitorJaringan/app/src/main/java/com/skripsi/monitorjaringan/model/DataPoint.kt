package com.skripsi.monitorjaringan.model

class DataPoint(var xValue: Int, var yValue: Double?)
